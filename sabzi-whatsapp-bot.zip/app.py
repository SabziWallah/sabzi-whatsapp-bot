
from flask import Flask, request
from twilio.twiml.messaging_response import MessagingResponse

app = Flask(__name__)

@app.route('/bot', methods=['POST'])
def bot():
    incoming_msg = request.values.get('Body', '').lower()
    resp = MessagingResponse()
    msg = resp.message()

    if 'hello' in incoming_msg:
        msg.body("Namaste! SabziWallah se kya mangwana hai? Example: 2 kilo aalu")
    else:
        msg.body("Aapka order mil gaya! Jaldi hi confirm karenge.")

    return str(resp)

if __name__ == '__main__':
    app.run(debug=True)
